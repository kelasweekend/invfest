{{-- <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, minimum-scale=1.0" />
    <link rel="icon" href="{{ asset('frontend/img/favicon.ico" type="image/x-icon') }}" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <!-- style CSS -->
    <link rel="stylesheet" href="{{ asset('frontend/css/style.css') }}" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <title>TRACKING</title>
</head>

<body class="bg-light">
    <!-- Bottom Navbar -->
    <nav class="
				navbar navbar-light navbar-expand
				p-0
				d-md-none d-lg-none d-xl-none
				fixed-bottom
				top-shadow
			"
        id="bottomNav">
        <ul class="navbar-nav nav-justified w-100">
            <li class="nav-item">
                <a href="index.html" class="nav-link"><i class="fas fa-home"></i>
                    <p>Home</p>
                </a>
            </li>
            <li class="nav-item">
                <a href="tracking.html" class="nav-link active"><i class="fas fa-info"></i>
                    <p>Tracking</p>
                </a>
            </li>
            <li class="nav-item">
                <a href="register.html" class="nav-link"><i class="fas fa-user"></i>
                    <p>Register</p>
                </a>
            </li>
        </ul>
    </nav>
    <!-- End of Bottom Navbar -->

    <div class="row pb-5 pb-md-0 vh-100 tracking">
        <div class="col-5 h-100 d-none d-lg-block overflow-hidden" style="background-color: #7e57c2">
            <div class="h-100 d-flex justify-content-center">
                <img src="{{asset('frontend/img/track.png')}}" class="details-img my-auto p-5 w-75" alt="alternative" />
            </div>
        </div>
        <div class="col-lg-7 col-md-12 overflow-auto pb-5">
            <div class="px-3 px-md-5 h-100">
                <a class="navbar-brand" href="index.html">
                    <img src="{{asset('frontend/img/logo.png')}}" width="120" class="d-inline-block align-top position-relative"
                        alt="" />
                </a>
                <hr class="mt-0" />
                <h2>Track Status Pendaftaran</h2>
                <form class="mt-2" action="{{route('track')}}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="inputNamaTim">Token</label>
                        <input type="text" name="invoice" class="form-control" id="inputNamaTim"
                            placeholder="Masukan token pendaftaran anda" />
                    </div>
                    <button type="submit" class="btn primary-color btn-rounded btn-block">
                        Submit
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>

</html> --}}


@extends('layouts.home')
@section('title')
    Track Team Anda
@endsection

@section('content')
    <!-- Header -->
    <header id="header">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <img src="{{ asset('frontend/img/track.png') }}" class="w-75 mt-5 mx-auto d-block" alt="alternative" />
                </div>
                <div class="col-md-7">
                    <h4 class="font-weight-bolder text-center mb-2 mt-5">
                        Check Status Team Anda
                    </h4>
                    <div class="card shadow-sm p-4">
                        @if (empty($status))
                            <form class="mt-2" action="{{ route('track') }}" method="POST">
                                @csrf
                                @if ($errors->all())
                                    @foreach ($errors->all() as $error)
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <strong>Warning !</strong> {{ $error }}
                                            <button type="button" class="close" data-dismiss="alert"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    @endforeach
                                @endif
                                @if ($message = Session::get('salah'))
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Warning !</strong> {{ $message }}
                                        <button type="button" class="close" data-dismiss="alert"
                                            aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                @endif
                                <p class="text-center text-muted">Silahkan masukan Token yang ada di Email Pendaftaran</p>
                                <div class="form-group">
                                    <input type="text" name="invoice" class="form-control" id="inputNamaTim"
                                        placeholder="Masukan token pendaftaran anda" />
                                </div>
                                <button type="submit" class="btn primary-color btn-rounded btn-block">
                                    Submit
                                </button>
                            </form>
                        @else
                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <td>Nama Team</td>
                                        <td>:</td>
                                        <td>{{ $status->nama_team }}</td>
                                    </tr>
                                    <tr>
                                        <td>Ketua Team</td>
                                        <td>:</td>
                                        <td>{{ $status->nama_ketua }}</td>
                                    </tr>
                                    <tr>
                                        <td>Tingkatan</td>
                                        <td>:</td>
                                        <td>{{ $status->tingkatan }}</td>
                                    </tr>
                                    <tr>
                                        <td>Status</td>
                                        <td>:</td>
                                        <td>
                                            @if ($status->status == '0')
                                                <span class="badge badge-danger">Belum Konfirmasi</span>
                                            @else
                                                <span class="badge badge-success">Terkonfirmasi</span>
                                            @endif
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            @if ($status->status == '0')
                                <a href="{{ route('sukses_daftar') }}" class="btn btn-secondary">Konfirmasi Pembayaran</a>
                            @endif
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- End of Header -->
@endsection

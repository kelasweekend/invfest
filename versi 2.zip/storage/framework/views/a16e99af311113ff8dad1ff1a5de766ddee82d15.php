<?php $__env->startSection('title'); ?>
    Pendaftaran Berhasil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <header id="header">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <img src="<?php echo e(asset('frontend/img/payment.svg')); ?>" class="w-75 mt-5 mx-auto d-block"
                        alt="alternative" />
                </div>
                <div class="col-md-6">
                    <h4 class="font-weight-bolder text-center mb-4 mt-5">
                        Konfirmasi Pembayaran
                    </h4>
                    <div class="card shadow-sm p-4">
                        <form class="mt-2" action="<?php echo e(route('konfirmasi')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->all()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Warning !</strong> <?php echo e($error); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <p class="text-center text-muted">Silahkan masukan Token yang ada di Email Pendaftaran</p>
                            <div class="form-group">
                                <label for="invoice">Masukan Kode Invoice</label>
                                <input type="text" name="invoice" class="form-control" id="invoice"
                                    placeholder="Masukan token pendaftaran anda" required />
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="pembayaran">Pilih Bank Transfer</label>
                                        <select class="form-control" id="pembayaran" name="bank" required>
                                          <option value="">Pilih Pembayaran</option>
                                          <?php $__currentLoopData = $pay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $harga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($harga->id); ?>"><?php echo e($harga->nama_bank); ?> | <?php echo e($harga->nomor_rekening); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                      </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="costumFile">Upload Bukti Pembayaran</label>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="customFile" name="image" required>
                                        <label class="custom-file-label" for="customFile">Choose file</label>
                                      </div>
                                </div>
                            </div>
                            <button type="submit" class="btn primary-color btn-rounded btn-block">
                                Submit
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- End of Header -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ojan/Documents/proyek laravel/invfest/resources/views/home/sukses.blade.php ENDPATH**/ ?>
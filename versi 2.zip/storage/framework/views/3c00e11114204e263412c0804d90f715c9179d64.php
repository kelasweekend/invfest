<?php $__env->startSection('title'); ?>
    Admin Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo $__env->yieldContent('title'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>">Admin</a></li>
                            <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <div class="container-fluid">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('errors')): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?><br />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-12">
                        <div class="info-box">
                            <span class="info-box-icon bg-info"><i class="far fa-user"></i></span>

                            <div class="info-box-content">
                                <span class="info-box-text">Jumlah Pendaftar</span>
                                <span class="info-box-number"><?php echo e($pendaftar); ?> Team</span>
                            </div>
                            <!-- /.info-box-content -->
                        </div>
                        <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-3 col-sm-6 col-12">
                        <div class="info-box">
                            <span class="info-box-icon bg-success"><i class="far fa-flag"></i></span>

                            <div class="info-box-content">
                                <span class="info-box-text">Jumlah Karya</span>
                                <span class="info-box-number"><?php echo e($karya); ?></span>
                            </div>
                            <!-- /.info-box-content -->
                        </div>
                        <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-3 col-sm-6 col-12">
                        <div class="info-box">
                            <span class="info-box-icon bg-warning"><i class="far fa-clock"></i></span>

                            <div class="info-box-content">
                                <span class="info-box-text">Tanggal Penutupan</span>
                                <span class="info-box-number"><?php echo e($web->pengumpulan); ?></span>
                            </div>
                            <!-- /.info-box-content -->
                        </div>
                        <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-3 col-sm-6 col-12">
                        <div class="info-box">
                            <span class="info-box-icon bg-danger"><i class="far fa-bookmark"></i></span>

                            <div class="info-box-content">
                                <span class="info-box-text">Kategori Lomba</span>
                                <span class="info-box-number"><?php echo e($kategori); ?> Item</span>
                            </div>
                            <!-- /.info-box-content -->
                        </div>
                        <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                </div>

                
                <div class="row">
                    <div class="col-12">
                        <!-- Default box -->
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Wejangan IT Team</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse"
                                        title="Collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                Selamat datang di dashboard admin Invfest, Silahkan setting keperluan website sesuai yang
                                ingin dibutuhkan, semua informasi website dapat di ubah melalui panel admin ini.
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <p class="text-danger">Harap mematuhi aturan yang telah ditetapkan system ini.</p>
                            </div>
                            <!-- /.card-footer-->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-12">
                        <!-- Default box -->
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Setting Web</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse"
                                        title="Collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <form role="form" action="<?php echo e(route('home.update')); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="Nama Event">Nama Event</label>
                                                <input type="text" class="form-control" id="Nama Event"
                                                    value="<?php echo e($web->title); ?>" name="title" required>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="form-group">
                                                <label for="Nama Event">Heading Event</label>
                                                <input type="text" class="form-control" id="Nama Event"
                                                    value="<?php echo e($web->heading); ?>" name="heading" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Tentang Event</label>
                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                            name="deskripsi"><?php echo e($web->deskripsi); ?></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="Nomor Panitia">Nomor Panitia</label>
                                                <input type="number" class="form-control" id="Nomor Panitia"
                                                    value="<?php echo e($web->nomor); ?>" name="nomor" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="Email_panitia">Email Panitia</label>
                                                <input type="email" class="form-control" id="Email_panitia"
                                                    value="<?php echo e($web->email); ?>" name="email" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="pengumpulan">Tanggal Pengumpulan</label>
                                                <input type="date" class="form-control" id="pengumpulan"
                                                    value="<?php echo e($web->pengumpulan); ?>" name="pengumpulan" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Logo Atas</label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" name="logo_atas"
                                                    id="customFile">
                                                <label class="custom-file-label" for="customFile">Choose file</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Logo Bawah</label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" name="logo_bawah"
                                                    id="customFile">
                                                <label class="custom-file-label" for="customFile">Choose file</label>
                                            </div>
                                        </div>
                                    </div>

                                    <?php if($web->maintenance == '1'): ?>
                                        <div class="form-check mt-3">
                                            <input type="checkbox" checked class="form-check-input" id="maintenance"
                                                name="maintenance">
                                            <label class="form-check-label" for="maintenance">Maintenace Mode</label>
                                        </div>
                                    <?php else: ?>
                                        <div class="form-check mt-3">
                                            <input type="checkbox" class="form-check-input" id="maintenance"
                                                name="maintenance">
                                            <label class="form-check-label" for="maintenance">Maintenace Mode</label>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
                            <!-- /.card-footer-->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ojan/Documents/proyek laravel/invfest/resources/views/admin/index.blade.php ENDPATH**/ ?>